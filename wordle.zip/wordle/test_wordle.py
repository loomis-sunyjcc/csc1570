import wordle
"""
    Testing of the functions located in wordle.py
"""
__author__ = "Your Name"

# get_hints tests

# load_word_list tests
word_list = wordle.load_word_list()
print ( f"Total number of words in dictionary: {len(word_list)}" )
if len(word_list) < 5:
    print ( word_list )
else:
    print ( f"The first and last 5 words:\n\t{word_list[:5]}\n\t{word_list[-5:]}" )
print ()

# get_word test
print ( f"5 random words from word_list: {[wordle.get_word(word_list, wordle.WORD_LENGTH) for _ in range(5)]}" )
print ()

# get_guess test
print ( "Type the following words to test input: ")
print ( "\tthing, Thing, THING")
print ( "All should be valid.")
for _ in range (3):
    wordle.get_guess(word_list, wordle.WORD_LENGTH)
print ( "Type the following words to test input: ")
print ( "\tabcde, ABCDE, 12345, tests" )
print ( "All should be invalid except the last.")
wordle.get_guess(word_list, wordle.WORD_LENGTH)

