from random import randrange
from collections import defaultdict

"""
    This is a simplified version of Wordle. The length of the
    target word to be guessed can be adjusted by changing the
    WORD_LENGTH constant below. The source of the dictionary of
    words to use is set in the DICTIONARY constant. Alternate language
    versions can be added by including additional dictionaries.

    Testing of the functions may be performed in the test_wordle.py
    program.

"""
__author__ = "Your Name"

WORD_LENGTH = 5
DICTIONARY = "dictionaries/large.dat"

def main ( ):
    """ Plays a game like Wordle where the user has as
        many tries to guess the word. Hints are provided such
        that the player has as many tries as the word is long
        to correctly guess.

        Here is an algorithm:
        Output "Welcome to Wordle!"
        word_list = load_word_list( )
        target = get_word ( word_list, WORD_LENGTH )
        count = 0
        word = "XXXXX"
        loop while hint != target and count <= 5
            Output get_hint ( target, word )
            word = get_word ( word_list, WORD_LENGTH )
            count = count + 1
        if hint == target then
            Output "Congrats, you won!"
        else
            Output "Better luck next time."
            Output "The correct answer was target"

    """
    print ( "Welcome to Wordle!")
    # Write the missing main code here

# Write get_hint here

def load_word_list( ):
    """ Loads the list of words from the English dictionary """
    with open( DICTIONARY, 'r' ) as file:
        wordlist = file.read().split()
    wordlist = [word.strip().upper() for word in wordlist if word.strip().isalpha()]
    return wordlist

def get_word ( wordlist, size ):
    """ Picks one word at random of the given size from the dictionary """
    index = randrange (0, len(wordlist))
    word = wordlist[index]
    while len(word) != size or not word in wordlist:
        index = randrange (0, len(wordlist))
        word = wordlist[index]
    return word

def get_guess ( wordlist, size ):
    """ Gets a guess of the correct size from the user. Words
        that are not in the dictionary are rejected. """
    guess = input ( "Guess:\t" ).upper()
    while ( len(guess) != size or guess not in wordlist ):
        guess = input ( "Not a valid word. Guess:\t" ).upper()
    return guess

if __name__ == "__main__":
    main()
