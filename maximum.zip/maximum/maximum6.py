"""
    Maximum Number Problem
    Attempt number six.

    This program will find the maximum of any count of
    given numbers. The numbers will be entered one at a
    time by the program user. When the user enters
    invalid input the user will be asked for a new input.
    If the input is "done", then the maximum number will be
    displayed.

"""
__author__ = "Ken Loomis"

def is_numeric ( num ):
    try:
        float ( num )
    except:
        return False
    return True

high_num = - float ("inf" ) # The current maximum
count = 1
done = False
while not done:
    num = input ( "Enter number " + str ( count ) + " (or \"done\" to quit): " )
    while not ( num.upper() == "DONE" or is_numeric ( num ) ):
        print ( "INVALID!", end=' ')
        num = input ( "Enter number " + str ( count ) + " (or \"done\" to quit): " )
    if num.upper() == "DONE":
        done = True
    else:
        high_num = max ( high_num, float ( num ) )
        count += 1
#end loop
print ( "The maximum number is", high_num )
#end
