"""
    Maximum Number Problem
    Attempt number one.

    This program will find the maximum of 10 given numbers.
    The numbers will be entered one at a time by the
    program user.

"""
__author__ = "Ken Loomis"

#The current maximum is negative infinity
high_num = - float ("inf" )
num = int ( input ( "Enter number 1: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 2: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 3: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 4: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 5: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 6: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 7: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 8: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 9: " ) )
high_num = max ( high_num, num )
num = int ( input ( "Enter number 10: " ) )
high_num = max ( high_num, num )
print ( "The maximum number is", high_num )
#end
