"""
    Maximum Number Problem
    Attempt number four.

    This program will find the maximum of any count of
    given numbers. The numbers will be entered one at
    a time by the program user. When the user enters a
    non-positive number the maximum number will be
    output to the screen.
    Note: the non-positive numbers will not be
    counted in the set of numbers.

"""
__author__ = "Ken Loomis"

high_num = - float("inf" ) # The current maximum
count = 1
# Expected input is a positive integer.
str_num = input ( "Enter number " + str ( count ) + ": " )
# while strnum != integer
while not str_num.isdigit():
    print ( "INVALID! Please enter only integers!!!" )
    str_num = input ( "Enter number " + str ( count ) + ": " )
while int ( str_num ) > 0:
    high_num = max ( high_num, int ( str_num ) )
    count += 1
    str_num = input ( "Enter number " + str ( count ) + ": " )
    while not str_num.isdigit():
        print ( "INVALID! Please enter only integers!!!" )
        str_num = input ( "Enter number " + str ( count ) + ": " )
#end loop
print ( "The maximum number is", high_num )
#end
