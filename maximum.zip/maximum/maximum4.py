"""
    Maximum Number Problem
    Attempt number four.

    This program will find the maximum of any count of
    given numbers. The numbers will be entered one at
    a time by the program user. When the user enters a
    non-positive number the maximum number will be
    output to the screen.
    Note: the non-positive numbers will not be
    counted in the set of numbers.

"""
__author__ = "Ken Loomis"

high_num = - float("inf" ) # The current maximum
count = 1
# termination condition when num <= 0, then stop
# continuation condition while num > 0, then continue
num = int ( input ( "Enter number " + str ( count ) + ": " ) )
while num > 0:
    high_num = max ( high_num, num )
    count += 1
    num = int ( input ( "Enter number " + str ( count ) + ": " ) )
#end loop
print ( "The maximum number is", high_num )
#end
