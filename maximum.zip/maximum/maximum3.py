"""
    Maximum Number Problem
    Attempt number three.

    This program will find the maximum of any count of
    given numbers. The count will be entered by the user
    The numbers will be entered one at a time by the
    program user.

"""
__author__ = "Ken Loomis"

high_num = - float ("inf" ) # The current maximum
# Ask for the number of iterations
loop_count = int ( input ( "Enter number of inputs: ") )
for count in range( 1, loop_count + 1 ):
    num = int ( input ( "Enter number " + str ( count ) + ": " ) )
    high_num = max ( high_num, num )
#end loop
print ( "The maximum number is", highNum )
#end
