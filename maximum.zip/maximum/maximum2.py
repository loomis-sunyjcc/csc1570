"""
    Maximum Number Problem
    Attempt number two.

    This program will find the maximum of 10 given numbers.
    The numbers will be entered one at a time by the
    program user.

"""
__author__ = "Ken Loomis"

high_num = - float ( "inf" ) # The current maximum
# loop for 10 iterations
for count in range( 1, 11 ):
    num = int ( input ( "Enter number " + str ( count ) + ": " ) )
    high_num = max ( high_num, num )
print ( "The maximum number is", high_num )
#end
