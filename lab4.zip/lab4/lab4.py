from movies import pg_movie, pg13_movie, restricted_movie
"""
    lab4.py
    Lab #4

    This lab allows us to explore complex if state
"""
__author__ = "Your Name"

# Part I
print ( "Welcome to Movie Night! Your random decider for what to watch." )
age = int ( input ( "Enter your age: " ) )

# Part II
print ( "What are you going to watch: " );

# Part III
print ( "How you getting to the theater: " );
